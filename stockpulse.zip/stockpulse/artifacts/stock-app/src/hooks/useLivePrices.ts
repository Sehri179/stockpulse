import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";

type PriceTick = {
  id: number;
  symbol: string;
  currentPrice: number;
  change: number;
  changePercent: number;
  highPrice: number;
  lowPrice: number;
  volume: number;
};

export function useLivePrices(onTick?: (ticks: PriceTick[]) => void) {
  const queryClient = useQueryClient();
  const esRef = useRef<EventSource | null>(null);

  useEffect(() => {
    const basePath = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";
    const url = `${basePath}/api/stocks/live`;
    const es = new EventSource(url, { withCredentials: true });
    esRef.current = es;

    es.onmessage = (event) => {
      try {
        const ticks: PriceTick[] = JSON.parse(event.data);

        queryClient.setQueriesData<PriceTick[]>(
          { queryKey: ["/api/stocks"] },
          (old) => {
            if (!old) return old;
            return old.map((stock) => {
              const tick = ticks.find((t) => t.id === stock.id);
              return tick ? { ...stock, ...tick } : stock;
            });
          },
        );

        queryClient.setQueriesData(
          { queryKey: ["/api/stocks/market/summary"] },
          (old: unknown) => {
            if (!old || typeof old !== "object") return old;
            const summary = old as {
              totalStocks: number;
              gainers: number;
              losers: number;
              topGainers: PriceTick[];
              topLosers: PriceTick[];
            };
            const applyTicks = (list: PriceTick[]) =>
              list.map((s) => {
                const t = ticks.find((tk) => tk.id === s.id);
                return t ? { ...s, ...t } : s;
              });
            const gainers = ticks.filter((t) => t.change >= 0).length;
            const losers = ticks.filter((t) => t.change < 0).length;
            return {
              ...summary,
              gainers,
              losers,
              topGainers: applyTicks(summary.topGainers ?? []),
              topLosers: applyTicks(summary.topLosers ?? []),
            };
          },
        );

        onTick?.(ticks);
      } catch {
        // ignore parse errors
      }
    };

    es.onerror = () => {
      es.close();
    };

    return () => {
      es.close();
    };
  }, []);

  return null;
}
