import { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { useLivePrices } from "@/hooks/useLivePrices";

function LivePricesProvider() {
  useLivePrices();
  return null;
}

export function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden">
      <LivePricesProvider />
      <Sidebar />
      <main className="flex-1 overflow-auto bg-muted/30">
        <div className="container mx-auto p-8 max-w-7xl">
          {children}
        </div>
      </main>
    </div>
  );
}
