import { useGetMe } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { ReactNode, useEffect } from "react";
import { Skeleton } from "./ui/skeleton";

export function ProtectedRoute({ children }: { children: ReactNode }) {
  const { data: user, isLoading, isError } = useGetMe();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && isError) {
      setLocation("/");
    }
  }, [isLoading, isError, setLocation]);

  if (isLoading) {
    return <div className="p-8"><Skeleton className="h-10 w-full mb-4" /><Skeleton className="h-64 w-full" /></div>;
  }

  if (isError || !user) {
    return null;
  }

  return <>{children}</>;
}
