import { useGetPortfolioSummaryReport, useGetProfitLossReport, useGetActivityReport } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

export default function Reports() {
  const { data: summary, isLoading: summaryLoading } = useGetPortfolioSummaryReport();
  const { data: pnl, isLoading: pnlLoading } = useGetProfitLossReport();
  const { data: activity, isLoading: activityLoading } = useGetActivityReport();

  const CHART_COLORS = ['hsl(var(--chart-1))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

  const assetAllocationData = summary ? [
    { name: 'Invested', value: summary.totalInvested },
    { name: 'Cash', value: summary.cashBalance }
  ] : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Reports & Analytics</h1>
        <p className="text-muted-foreground">Comprehensive overview of your trading performance.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Performance Summary</CardTitle>
            <CardDescription>Overall portfolio metrics</CardDescription>
          </CardHeader>
          <CardContent>
            {summaryLoading ? <Skeleton className="h-40 w-full" /> : (
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Total Return</p>
                  <p className={`text-2xl font-bold ${summary!.totalReturn >= 0 ? 'text-success' : 'text-destructive'}`}>
                    ${summary?.totalReturn.toFixed(2)}
                  </p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Return %</p>
                  <p className={`text-2xl font-bold ${summary!.returnPercent >= 0 ? 'text-success' : 'text-destructive'}`}>
                    {summary?.returnPercent.toFixed(2)}%
                  </p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Best Performer</p>
                  <p className="text-xl font-bold">{summary?.bestPerformer?.symbol || 'N/A'}</p>
                  <p className="text-xs text-success">{summary?.bestPerformer?.gainLossPercent ? `+${summary.bestPerformer.gainLossPercent.toFixed(2)}%` : ''}</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm text-muted-foreground">Worst Performer</p>
                  <p className="text-xl font-bold">{summary?.worstPerformer?.symbol || 'N/A'}</p>
                  <p className="text-xs text-destructive">{summary?.worstPerformer?.gainLossPercent ? `${summary.worstPerformer.gainLossPercent.toFixed(2)}%` : ''}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Asset Allocation</CardTitle>
            <CardDescription>Cash vs Invested Capital</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center items-center h-[200px]">
            {summaryLoading ? <Skeleton className="h-[150px] w-[150px] rounded-full" /> : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={assetAllocationData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {assetAllocationData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => `$${value.toFixed(2)}`}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderRadius: '8px', border: '1px solid hsl(var(--border))' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Trade Statistics</CardTitle>
            <CardDescription>Win/loss ratio and trade counts</CardDescription>
          </CardHeader>
          <CardContent>
            {pnlLoading ? <Skeleton className="h-40 w-full" /> : (
              <div className="space-y-4">
                <div className="flex justify-between items-center pb-2 border-b">
                  <span className="text-muted-foreground">Total Trades</span>
                  <span className="font-bold text-lg">{pnl?.tradeCount}</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b">
                  <span className="text-muted-foreground">Profitable Trades</span>
                  <span className="font-bold text-lg text-success">{pnl?.profitableTrades}</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b">
                  <span className="text-muted-foreground">Losing Trades</span>
                  <span className="font-bold text-lg text-destructive">{pnl?.losingTrades}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Win Rate</span>
                  <span className="font-bold text-xl text-primary">{pnl?.winRate.toFixed(1)}%</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity Log</CardTitle>
            <CardDescription>Latest system events</CardDescription>
          </CardHeader>
          <CardContent>
            {activityLoading ? <Skeleton className="h-40 w-full" /> : (
              <div className="space-y-4 max-h-[220px] overflow-y-auto pr-2">
                {activity?.map(act => (
                  <div key={act.id} className="flex flex-col pb-3 border-b last:border-0 last:pb-0">
                    <div className="flex justify-between items-start">
                      <span className="font-medium text-sm">{act.description}</span>
                      <span className="text-xs text-muted-foreground">{new Date(act.createdAt).toLocaleDateString()}</span>
                    </div>
                    {act.amount && <span className="text-sm text-primary font-semibold mt-1">${act.amount.toFixed(2)}</span>}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
