import { useGetPortfolio, useGetWatchlist, useListHoldings } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

export default function Portfolio() {
  const { data: portfolio, isLoading: portfolioLoading } = useGetPortfolio();
  const { data: holdings, isLoading: holdingsLoading } = useListHoldings();
  const { data: watchlist, isLoading: watchlistLoading } = useGetWatchlist();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Portfolio</h1>
        <p className="text-muted-foreground">Manage your holdings and watchlist.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="col-span-1 bg-primary text-primary-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium opacity-80">Total Value</CardTitle>
          </CardHeader>
          <CardContent>
            {portfolioLoading ? <Skeleton className="h-8 w-32 bg-primary-foreground/20" /> : (
              <div className="text-4xl font-bold">${portfolio?.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            )}
          </CardContent>
        </Card>
        
        <Card className="col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Gain/Loss</CardTitle>
          </CardHeader>
          <CardContent>
            {portfolioLoading ? <Skeleton className="h-8 w-32" /> : (
              <div>
                <div className={`text-2xl font-bold ${(portfolio?.totalGainLoss || 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {(portfolio?.totalGainLoss || 0) >= 0 ? '+' : '-'}${Math.abs(portfolio?.totalGainLoss || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div className={`text-sm font-medium ${(portfolio?.totalGainLossPercent || 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {(portfolio?.totalGainLossPercent || 0) >= 0 ? '+' : ''}{(portfolio?.totalGainLossPercent || 0).toFixed(2)}%
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Cash Balance</CardTitle>
          </CardHeader>
          <CardContent>
            {portfolioLoading ? <Skeleton className="h-8 w-32" /> : (
              <div className="text-2xl font-bold">${portfolio?.cashBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Current Holdings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead className="text-right">Qty</TableHead>
                  <TableHead className="text-right">Avg Price</TableHead>
                  <TableHead className="text-right">Current Price</TableHead>
                  <TableHead className="text-right">Total Value</TableHead>
                  <TableHead className="text-right">Gain/Loss</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {holdingsLoading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-12" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-8 ml-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 ml-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 ml-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-20 ml-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-24 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : holdings?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
                      No current holdings. Go buy some stocks!
                    </TableCell>
                  </TableRow>
                ) : (
                  holdings?.map((h) => (
                    <TableRow key={h.id}>
                      <TableCell className="font-semibold text-primary">
                        <Link href={`/stocks/${h.symbol}`}>
                          <span className="cursor-pointer hover:underline">{h.symbol}</span>
                        </Link>
                      </TableCell>
                      <TableCell className="text-right font-medium">{h.quantity}</TableCell>
                      <TableCell className="text-right">${h.averagePrice.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-medium">${h.currentPrice.toFixed(2)}</TableCell>
                      <TableCell className="text-right font-bold">${h.totalValue.toFixed(2)}</TableCell>
                      <TableCell className={`text-right font-medium ${h.gainLoss >= 0 ? 'text-success' : 'text-destructive'}`}>
                        {h.gainLoss >= 0 ? '+' : ''}{h.gainLoss.toFixed(2)} ({h.gainLossPercent.toFixed(2)}%)
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Watchlist</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Change</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {watchlistLoading ? (
                  Array.from({ length: 2 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-5 w-12" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 ml-auto" /></TableCell>
                      <TableCell><Skeleton className="h-5 w-16 ml-auto" /></TableCell>
                    </TableRow>
                  ))
                ) : watchlist?.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center h-24 text-muted-foreground">
                      Your watchlist is empty.
                    </TableCell>
                  </TableRow>
                ) : (
                  watchlist?.map((w) => (
                    <TableRow key={w.id}>
                      <TableCell className="font-semibold text-primary">
                        <Link href={`/stocks/${w.symbol}`}>
                          <span className="cursor-pointer hover:underline">{w.symbol}</span>
                        </Link>
                      </TableCell>
                      <TableCell>{w.name}</TableCell>
                      <TableCell className="text-right font-medium">${w.currentPrice.toFixed(2)}</TableCell>
                      <TableCell className={`text-right font-medium ${w.changePercent >= 0 ? 'text-success' : 'text-destructive'}`}>
                        {w.changePercent >= 0 ? '+' : ''}{w.changePercent.toFixed(2)}%
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
