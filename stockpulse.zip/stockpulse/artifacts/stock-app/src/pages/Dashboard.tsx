import { useGetMarketSummary, useGetPortfolio, useGetActivityReport } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowDownIcon, ArrowUpIcon, Activity } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: marketSummary, isLoading: marketLoading } = useGetMarketSummary();
  const { data: portfolio, isLoading: portfolioLoading } = useGetPortfolio();
  const { data: activityData, isLoading: activityLoading } = useGetActivityReport();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back. Here is your market overview.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Portfolio Value</CardTitle>
          </CardHeader>
          <CardContent>
            {portfolioLoading ? (
              <Skeleton className="h-8 w-full" />
            ) : (
              <>
                <div className="text-2xl font-bold">${portfolio?.totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  Cash: ${portfolio?.cashBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </p>
              </>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Return</CardTitle>
          </CardHeader>
          <CardContent>
            {portfolioLoading ? (
              <Skeleton className="h-8 w-full" />
            ) : (
              <>
                <div className={`text-2xl font-bold flex items-center ${(portfolio?.totalGainLoss || 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {(portfolio?.totalGainLoss || 0) >= 0 ? <ArrowUpIcon className="mr-1 h-5 w-5" /> : <ArrowDownIcon className="mr-1 h-5 w-5" />}
                  ${Math.abs(portfolio?.totalGainLoss || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <p className={`text-xs mt-1 ${(portfolio?.totalGainLossPercent || 0) >= 0 ? 'text-success' : 'text-destructive'}`}>
                  {(portfolio?.totalGainLossPercent || 0) >= 0 ? '+' : ''}{(portfolio?.totalGainLossPercent || 0).toFixed(2)}%
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Market Active Stocks</CardTitle>
          </CardHeader>
          <CardContent>
            {marketLoading ? (
              <Skeleton className="h-8 w-full" />
            ) : (
              <div className="text-2xl font-bold">{marketSummary?.totalStocks}</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Market Sentiment</CardTitle>
          </CardHeader>
          <CardContent>
            {marketLoading ? (
              <Skeleton className="h-8 w-full" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {marketSummary ? (marketSummary.gainers > marketSummary.losers ? "Bullish" : "Bearish") : "-"}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {marketSummary?.gainers} Advancing / {marketSummary?.losers} Declining
                </p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Top Gainers</CardTitle>
          </CardHeader>
          <CardContent>
            {marketLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : (
              <div className="space-y-4">
                {marketSummary?.topGainers.map(stock => (
                  <div key={stock.symbol} className="flex items-center justify-between">
                    <div>
                      <Link href={`/stocks/${stock.symbol}`}>
                        <span className="font-semibold cursor-pointer hover:underline">{stock.symbol}</span>
                      </Link>
                      <p className="text-xs text-muted-foreground">{stock.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">${stock.currentPrice.toFixed(2)}</p>
                      <p className="text-sm text-success">+{stock.changePercent.toFixed(2)}%</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Top Losers</CardTitle>
          </CardHeader>
          <CardContent>
            {marketLoading ? (
              <div className="space-y-2">
                {[1, 2, 3].map(i => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : (
              <div className="space-y-4">
                {marketSummary?.topLosers.map(stock => (
                  <div key={stock.symbol} className="flex items-center justify-between">
                    <div>
                      <Link href={`/stocks/${stock.symbol}`}>
                        <span className="font-semibold cursor-pointer hover:underline">{stock.symbol}</span>
                      </Link>
                      <p className="text-xs text-muted-foreground">{stock.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">${stock.currentPrice.toFixed(2)}</p>
                      <p className="text-sm text-destructive">{stock.changePercent.toFixed(2)}%</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="h-5 w-5 mr-2" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {activityLoading ? (
             <div className="space-y-4">
               {[1, 2, 3].map(i => <Skeleton key={i} className="h-10 w-full" />)}
             </div>
          ) : (
            <div className="space-y-4">
              {activityData?.length === 0 ? (
                <p className="text-sm text-muted-foreground">No recent activity.</p>
              ) : (
                activityData?.slice(0, 5).map(activity => (
                  <div key={activity.id} className="flex items-center justify-between border-b last:border-0 pb-3 last:pb-0">
                    <div>
                      <p className="text-sm font-medium">{activity.description}</p>
                      <p className="text-xs text-muted-foreground">{new Date(activity.createdAt).toLocaleString()}</p>
                    </div>
                    <div className="font-medium">
                      {activity.amount ? `$${activity.amount.toFixed(2)}` : ''}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
