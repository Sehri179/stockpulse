import { useState } from "react";
import { useRoute } from "wouter";
import { 
  useGetStock, 
  useGetStockHistory, 
  useCreateOrder,
  useAddToWatchlist,
  useRemoveFromWatchlist,
  useGetWatchlist,
  getListOrdersQueryKey,
  getGetPortfolioQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { ArrowDownIcon, ArrowUpIcon, Star, StarIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

const orderSchema = z.object({
  quantity: z.coerce.number().min(1),
  limitPrice: z.coerce.number().optional().or(z.literal(''))
});

export default function StockDetail() {
  const [, params] = useRoute("/stocks/:symbol");
  const symbol = params?.symbol || "";
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: stock, isLoading } = useGetStock(symbol, { query: { enabled: !!symbol } });
  const { data: history } = useGetStockHistory({ symbol, days: 30 }, { query: { enabled: !!symbol } });
  const { data: watchlist } = useGetWatchlist();
  
  const isWatchlisted = watchlist?.some(w => w.symbol === symbol);
  
  const createOrder = useCreateOrder();
  const addToWatchlist = useAddToWatchlist();
  const removeFromWatchlist = useRemoveFromWatchlist();

  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [orderType, setOrderType] = useState<'buy'|'sell'>('buy');

  const form = useForm<z.infer<typeof orderSchema>>({
    resolver: zodResolver(orderSchema),
    defaultValues: { quantity: 1 }
  });

  const onSubmitOrder = (values: z.infer<typeof orderSchema>) => {
    createOrder.mutate({ 
      data: { 
        symbol, 
        type: orderType, 
        quantity: values.quantity,
        limitPrice: values.limitPrice ? Number(values.limitPrice) : undefined
      } 
    }, {
      onSuccess: () => {
        toast({ title: "Order placed successfully" });
        setOrderModalOpen(false);
        queryClient.invalidateQueries({ queryKey: getListOrdersQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetPortfolioQueryKey() });
        form.reset();
      },
      onError: (err) => {
        toast({ title: "Order failed", description: String(err), variant: "destructive" });
      }
    });
  };

  const toggleWatchlist = () => {
    if (isWatchlisted) {
      const item = watchlist?.find(w => w.symbol === symbol);
      if (item) {
        removeFromWatchlist.mutate({ symbol }, {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['/api/watchlist'] });
            toast({ title: "Removed from watchlist" });
          }
        });
      }
    } else {
      addToWatchlist.mutate({ symbol }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['/api/watchlist'] });
          toast({ title: "Added to watchlist" });
        }
      });
    }
  };

  if (isLoading) {
    return <div className="p-8 space-y-6"><Skeleton className="h-32 w-full" /><Skeleton className="h-[400px] w-full" /></div>;
  }

  if (!stock) return <div className="p-8 text-center text-muted-foreground">Stock not found</div>;

  const isPositive = stock.change >= 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-4xl font-bold tracking-tight">{stock.symbol}</h1>
            <Button variant="ghost" size="icon" onClick={toggleWatchlist}>
              <StarIcon className={`h-6 w-6 ${isWatchlisted ? 'fill-yellow-400 text-yellow-400' : 'text-muted-foreground'}`} />
            </Button>
          </div>
          <p className="text-xl text-muted-foreground mt-1">{stock.name}</p>
        </div>
        <div className="text-right">
          <div className="text-4xl font-bold">${stock.currentPrice.toFixed(2)}</div>
          <div className={`text-lg flex items-center justify-end font-medium ${isPositive ? 'text-success' : 'text-destructive'}`}>
            {isPositive ? <ArrowUpIcon className="mr-1 h-5 w-5" /> : <ArrowDownIcon className="mr-1 h-5 w-5" />}
            {Math.abs(stock.change).toFixed(2)} ({Math.abs(stock.changePercent).toFixed(2)}%)
          </div>
        </div>
      </div>

      <div className="flex gap-4 mb-6">
        <Button onClick={() => { setOrderType('buy'); setOrderModalOpen(true); }} className="w-32 bg-primary">Buy</Button>
        <Button onClick={() => { setOrderType('sell'); setOrderModalOpen(true); }} variant="outline" className="w-32 text-destructive border-destructive hover:bg-destructive/10">Sell</Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Price History (30 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px] w-full">
            {history ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="date" tickFormatter={(v) => new Date(v).toLocaleDateString(undefined, {month: 'short', day: 'numeric'})} stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis domain={['auto', 'auto']} stroke="hsl(var(--muted-foreground))" fontSize={12} tickFormatter={(v) => `$${v}`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                    itemStyle={{ color: 'hsl(var(--foreground))' }}
                    labelFormatter={(v) => new Date(v).toLocaleDateString()}
                  />
                  <Line type="monotone" dataKey="close" stroke={isPositive ? 'hsl(var(--success))' : 'hsl(var(--destructive))'} strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <Skeleton className="h-full w-full" />
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Open</CardTitle></CardHeader>
          <CardContent><p className="text-2xl font-semibold">${stock.openPrice.toFixed(2)}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">High</CardTitle></CardHeader>
          <CardContent><p className="text-2xl font-semibold">${stock.highPrice.toFixed(2)}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Low</CardTitle></CardHeader>
          <CardContent><p className="text-2xl font-semibold">${stock.lowPrice.toFixed(2)}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Volume</CardTitle></CardHeader>
          <CardContent><p className="text-2xl font-semibold">{stock.volume.toLocaleString()}</p></CardContent>
        </Card>
      </div>

      <Dialog open={orderModalOpen} onOpenChange={setOrderModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Place Order: {symbol}</DialogTitle>
            <DialogDescription>Current Price: ${stock.currentPrice.toFixed(2)}</DialogDescription>
          </DialogHeader>
          <Tabs value={orderType} onValueChange={(v) => setOrderType(v as 'buy'|'sell')} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="buy">Buy</TabsTrigger>
              <TabsTrigger value="sell">Sell</TabsTrigger>
            </TabsList>
            <div className="mt-4">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmitOrder)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quantity</FormLabel>
                        <FormControl><Input type="number" min="1" {...field} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="limitPrice"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Limit Price (Optional)</FormLabel>
                        <FormControl><Input type="number" step="0.01" placeholder="Leave blank for market order" {...field} value={field.value ?? ''} /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="py-2 border-t mt-4 text-sm flex justify-between">
                    <span className="font-medium text-muted-foreground">Estimated Total</span>
                    <span className="font-bold">${((form.watch('quantity') || 0) * (form.watch('limitPrice') ? Number(form.watch('limitPrice')) : stock.currentPrice)).toFixed(2)}</span>
                  </div>
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setOrderModalOpen(false)}>Cancel</Button>
                    <Button type="submit" disabled={createOrder.isPending} className={orderType === 'buy' ? 'bg-primary' : 'bg-destructive hover:bg-destructive/90 text-white'}>
                      {createOrder.isPending ? "Processing..." : `Confirm ${orderType === 'buy' ? 'Buy' : 'Sell'}`}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </div>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
}
