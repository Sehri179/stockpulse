import { useState, useRef, useEffect } from "react";
import { useListStocks } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Search, Wifi } from "lucide-react";
import { Link } from "wouter";

type StockRow = {
  id: number;
  symbol: string;
  name: string;
  sector: string | null;
  currentPrice: number;
  change: number;
  changePercent: number;
  volume: number;
};

function useFlash(value: number) {
  const [flash, setFlash] = useState<"up" | "down" | null>(null);
  const prevRef = useRef<number>(value);

  useEffect(() => {
    if (prevRef.current === value) return;
    const dir = value > prevRef.current ? "up" : "down";
    prevRef.current = value;
    setFlash(dir);
    const t = setTimeout(() => setFlash(null), 600);
    return () => clearTimeout(t);
  }, [value]);

  return flash;
}

function PriceCell({ price, change }: { price: number; change: number }) {
  const flash = useFlash(price);
  return (
    <TableCell
      className={`text-right font-mono font-semibold transition-colors duration-300 ${
        flash === "up"
          ? "text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40"
          : flash === "down"
            ? "text-red-600 bg-red-50 dark:bg-red-950/40"
            : change >= 0
              ? "text-foreground"
              : "text-foreground"
      }`}
    >
      ${price.toFixed(2)}
    </TableCell>
  );
}

export default function Stocks() {
  const [search, setSearch] = useState("");
  const { data: stocks, isLoading } = useListStocks({ search: search || undefined });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Market Explorer</h1>
          <p className="text-muted-foreground">Browse and search available stocks.</p>
        </div>
        <Badge variant="outline" className="gap-1.5 text-emerald-600 border-emerald-200 bg-emerald-50">
          <Wifi className="h-3 w-3 animate-pulse" />
          Live
        </Badge>
      </div>

      <div className="relative w-full max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search symbols or names..."
          className="pl-9"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="border rounded-md">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Symbol</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Sector</TableHead>
              <TableHead className="text-right">Price</TableHead>
              <TableHead className="text-right">Change</TableHead>
              <TableHead className="text-right">Volume</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 10 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-6 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-16 ml-auto" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-16 ml-auto" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-20 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : stocks?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
                  No stocks found matching "{search}"
                </TableCell>
              </TableRow>
            ) : (
              (stocks as StockRow[] | undefined)?.map((stock) => (
                <TableRow key={stock.symbol} className="group">
                  <TableCell className="font-semibold text-primary">
                    <Link href={`/stocks/${stock.symbol}`}>
                      <span className="cursor-pointer hover:underline">{stock.symbol}</span>
                    </Link>
                  </TableCell>
                  <TableCell>{stock.name}</TableCell>
                  <TableCell className="text-muted-foreground">{stock.sector || "N/A"}</TableCell>
                  <PriceCell price={stock.currentPrice} change={stock.change} />
                  <TableCell className={`text-right font-medium ${stock.change >= 0 ? "text-emerald-600" : "text-red-500"}`}>
                    {stock.change >= 0 ? "+" : ""}{stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
                  </TableCell>
                  <TableCell className="text-right text-muted-foreground font-mono text-sm">
                    {stock.volume.toLocaleString()}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
