import { useListAlerts, useCreateAlert, useDeleteAlert, getListAlertsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Trash2, Bell } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const alertSchema = z.object({
  symbol: z.string().min(1, "Symbol is required").toUpperCase(),
  targetPrice: z.coerce.number().min(0.01, "Valid price required"),
  condition: z.enum(['above', 'below'])
});

export default function Alerts() {
  const { data: alerts, isLoading } = useListAlerts();
  const createAlert = useCreateAlert();
  const deleteAlert = useDeleteAlert();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const form = useForm<z.infer<typeof alertSchema>>({
    resolver: zodResolver(alertSchema),
    defaultValues: { symbol: "", targetPrice: 0, condition: "above" }
  });

  const onSubmit = (values: z.infer<typeof alertSchema>) => {
    createAlert.mutate({ data: values }, {
      onSuccess: () => {
        toast({ title: "Alert created successfully" });
        queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey() });
        form.reset();
      },
      onError: (err) => toast({ title: "Failed to create alert", description: String(err), variant: "destructive" })
    });
  };

  const handleDelete = (id: number) => {
    deleteAlert.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Alert deleted" });
        queryClient.invalidateQueries({ queryKey: getListAlertsQueryKey() });
      }
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Price Alerts</h1>
        <p className="text-muted-foreground">Get notified when stocks hit your target prices.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="col-span-1 h-fit">
          <CardHeader>
            <CardTitle className="text-lg">Create New Alert</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="symbol"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Symbol</FormLabel>
                      <FormControl><Input placeholder="AAPL" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="condition"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Condition</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select condition" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="above">Goes Above</SelectItem>
                          <SelectItem value="below">Drops Below</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="targetPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Price ($)</FormLabel>
                      <FormControl><Input type="number" step="0.01" {...field} /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={createAlert.isPending}>
                  <Bell className="w-4 h-4 mr-2" />
                  {createAlert.isPending ? "Creating..." : "Create Alert"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Active Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Symbol</TableHead>
                    <TableHead>Condition</TableHead>
                    <TableHead className="text-right">Target Price</TableHead>
                    <TableHead className="text-right">Current Price</TableHead>
                    <TableHead className="text-center">Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow><TableCell colSpan={6} className="text-center">Loading...</TableCell></TableRow>
                  ) : alerts?.length === 0 ? (
                    <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground h-24">No alerts configured.</TableCell></TableRow>
                  ) : (
                    alerts?.map(alert => (
                      <TableRow key={alert.id}>
                        <TableCell className="font-semibold">{alert.symbol}</TableCell>
                        <TableCell className="capitalize text-muted-foreground">{alert.condition}</TableCell>
                        <TableCell className="text-right font-medium">${alert.targetPrice.toFixed(2)}</TableCell>
                        <TableCell className="text-right text-muted-foreground">${alert.currentPrice.toFixed(2)}</TableCell>
                        <TableCell className="text-center">
                          {alert.isTriggered ? <Badge variant="destructive">Triggered</Badge> : <Badge variant="outline" className="text-success border-success">Active</Badge>}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="icon" onClick={() => handleDelete(alert.id)} disabled={deleteAlert.isPending}>
                            <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive transition-colors" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
