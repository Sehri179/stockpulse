import { db, stocksTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";

export type PriceTick = {
  id: number;
  symbol: string;
  currentPrice: number;
  change: number;
  changePercent: number;
  highPrice: number;
  lowPrice: number;
  volume: number;
};

type SseClient = {
  id: string;
  write: (data: string) => void;
};

const clients = new Map<string, SseClient>();

export function addSseClient(client: SseClient) {
  clients.set(client.id, client);
  logger.info({ clientId: client.id, total: clients.size }, "SSE client connected");
}

export function removeSseClient(id: string) {
  clients.delete(id);
  logger.info({ clientId: id, total: clients.size }, "SSE client disconnected");
}

function broadcast(ticks: PriceTick[]) {
  const payload = `data: ${JSON.stringify(ticks)}\n\n`;
  for (const client of clients.values()) {
    try {
      client.write(payload);
    } catch {
      clients.delete(client.id);
    }
  }
}

const openPrices = new Map<number, number>();

export async function startPriceSimulator() {
  const stocks = await db.select().from(stocksTable);
  for (const s of stocks) {
    openPrices.set(s.id, s.openPrice);
  }
  logger.info({ stocks: stocks.length }, "Price simulator started");

  setInterval(async () => {
    try {
      const current = await db.select().from(stocksTable);
      const ticks: PriceTick[] = [];

      for (const stock of current) {
        const delta = (Math.random() - 0.495) * stock.currentPrice * 0.003;
        const newPrice = Math.max(stock.currentPrice + delta, 0.01);
        const roundedPrice = parseFloat(newPrice.toFixed(2));

        const open = openPrices.get(stock.id) ?? stock.openPrice;
        const change = parseFloat((roundedPrice - open).toFixed(2));
        const changePercent = parseFloat(((change / open) * 100).toFixed(2));
        const newHigh = Math.max(stock.highPrice, roundedPrice);
        const newLow = Math.min(stock.lowPrice, roundedPrice);
        const newVolume = stock.volume + Math.floor(Math.random() * 50000);

        await db
          .update(stocksTable)
          .set({ currentPrice: roundedPrice, change, changePercent, highPrice: newHigh, lowPrice: newLow, volume: newVolume })
          .where(eq(stocksTable.id, stock.id));

        ticks.push({ id: stock.id, symbol: stock.symbol, currentPrice: roundedPrice, change, changePercent, highPrice: newHigh, lowPrice: newLow, volume: newVolume });
      }

      if (clients.size > 0) {
        broadcast(ticks);
      }
    } catch (err) {
      logger.error({ err }, "Price simulator tick error");
    }
  }, 3000);
}
