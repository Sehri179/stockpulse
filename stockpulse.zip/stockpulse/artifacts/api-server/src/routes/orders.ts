import { Router } from "express";
import { db, ordersTable, holdingsTable, stocksTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { z } from "zod";

const router = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return null; }
  return userId;
}

const createOrderSchema = z.object({
  symbol: z.string().min(1),
  type: z.enum(["buy", "sell"]),
  quantity: z.number().positive(),
  limitPrice: z.number().optional().nullable(),
});

function orderToResponse(o: typeof ordersTable.$inferSelect) {
  return {
    id: o.id,
    userId: o.userId,
    symbol: o.symbol,
    name: o.name,
    type: o.type,
    quantity: o.quantity,
    price: o.price,
    totalAmount: o.totalAmount,
    fees: o.fees,
    status: o.status,
    createdAt: o.createdAt.toISOString(),
  };
}

router.get("/", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  const orders = await db.select().from(ordersTable).where(eq(ordersTable.userId, userId));
  res.json(orders.map(orderToResponse));
});

router.get("/:id", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;
  const id = parseInt(req.params.id, 10);
  const [order] = await db.select().from(ordersTable).where(and(eq(ordersTable.id, id), eq(ordersTable.userId, userId))).limit(1);
  if (!order) { res.status(404).json({ error: "Order not found" }); return; }
  res.json(orderToResponse(order));
});

router.post("/", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = createOrderSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { symbol, type, quantity, limitPrice } = parsed.data;
  const sym = symbol.toUpperCase();

  const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.symbol, sym)).limit(1);
  if (!stock) { res.status(404).json({ error: "Stock not found" }); return; }

  const price = limitPrice ?? stock.currentPrice;
  const fees = Math.round(price * quantity * 0.001 * 100) / 100; // 0.1% fee
  const totalAmount = price * quantity + fees;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  if (!user) { res.status(401).json({ error: "User not found" }); return; }

  if (type === "buy") {
    if (user.balance < totalAmount) { res.status(400).json({ error: "Insufficient funds" }); return; }

    // Deduct balance
    await db.update(usersTable).set({ balance: user.balance - totalAmount }).where(eq(usersTable.id, userId));

    // Update or create holding
    const [existing] = await db.select().from(holdingsTable).where(and(eq(holdingsTable.userId, userId), eq(holdingsTable.symbol, sym))).limit(1);
    if (existing) {
      const newQty = existing.quantity + quantity;
      const newAvg = (existing.quantity * existing.averagePrice + quantity * price) / newQty;
      await db.update(holdingsTable).set({ quantity: newQty, averagePrice: newAvg }).where(eq(holdingsTable.id, existing.id));
    } else {
      await db.insert(holdingsTable).values({ userId, stockId: stock.id, symbol: sym, quantity, averagePrice: price });
    }
  } else {
    // sell
    const [existing] = await db.select().from(holdingsTable).where(and(eq(holdingsTable.userId, userId), eq(holdingsTable.symbol, sym))).limit(1);
    if (!existing || existing.quantity < quantity) { res.status(400).json({ error: "Insufficient shares" }); return; }

    const proceeds = price * quantity - fees;
    await db.update(usersTable).set({ balance: user.balance + proceeds }).where(eq(usersTable.id, userId));

    const newQty = existing.quantity - quantity;
    if (newQty < 0.0001) {
      await db.delete(holdingsTable).where(eq(holdingsTable.id, existing.id));
    } else {
      await db.update(holdingsTable).set({ quantity: newQty }).where(eq(holdingsTable.id, existing.id));
    }
  }

  const [order] = await db.insert(ordersTable).values({
    userId,
    stockId: stock.id,
    symbol: sym,
    name: stock.name,
    type,
    quantity,
    price,
    totalAmount,
    fees,
    status: "executed",
  }).returning();

  res.status(201).json(orderToResponse(order));
});

export default router;
