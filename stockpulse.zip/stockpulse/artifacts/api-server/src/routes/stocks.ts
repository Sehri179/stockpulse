import { Router } from "express";
import { db, stocksTable, priceHistoryTable } from "@workspace/db";
import { eq, ilike, or } from "drizzle-orm";
import { addSseClient, removeSseClient } from "../lib/priceSimulator";

const router = Router();

function stockToResponse(s: typeof stocksTable.$inferSelect) {
  return {
    id: s.id,
    symbol: s.symbol,
    name: s.name,
    currentPrice: s.currentPrice,
    openPrice: s.openPrice,
    highPrice: s.highPrice,
    lowPrice: s.lowPrice,
    volume: s.volume,
    change: s.change,
    changePercent: s.changePercent,
    sector: s.sector ?? null,
  };
}

router.get("/", async (req, res): Promise<void> => {
  const search = req.query.search as string | undefined;
  let stocks;
  if (search) {
    stocks = await db.select().from(stocksTable).where(
      or(
        ilike(stocksTable.symbol, `%${search}%`),
        ilike(stocksTable.name, `%${search}%`)
      )
    );
  } else {
    stocks = await db.select().from(stocksTable);
  }
  res.json(stocks.map(stockToResponse));
});

router.get("/live", (req, res): void => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  addSseClient({ id, write: (data) => res.write(data) });

  req.on("close", () => removeSseClient(id));
});

router.get("/market/summary", async (req, res): Promise<void> => {
  const stocks = await db.select().from(stocksTable);
  const gainers = stocks.filter(s => s.changePercent > 0).length;
  const losers = stocks.filter(s => s.changePercent < 0).length;
  const sorted = [...stocks].sort((a, b) => b.changePercent - a.changePercent);
  const topGainers = sorted.slice(0, 5).map(stockToResponse);
  const topLosers = sorted.slice(-5).reverse().map(stockToResponse);
  res.json({ totalStocks: stocks.length, gainers, losers, topGainers, topLosers });
});

router.get("/history", async (req, res): Promise<void> => {
  const symbol = req.query.symbol as string;
  const days = parseInt(req.query.days as string || "30", 10);
  if (!symbol) {
    res.status(400).json({ error: "symbol required" });
    return;
  }
  const history = await db.select().from(priceHistoryTable)
    .where(eq(priceHistoryTable.symbol, symbol.toUpperCase()))
    .limit(days);
  res.json(history.map(h => ({
    date: h.date,
    open: h.open,
    high: h.high,
    low: h.low,
    close: h.close,
    volume: h.volume,
  })));
});

router.get("/:symbol", async (req, res): Promise<void> => {
  const symbol = req.params.symbol.toUpperCase();
  const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.symbol, symbol)).limit(1);
  if (!stock) {
    res.status(404).json({ error: "Stock not found" });
    return;
  }
  res.json(stockToResponse(stock));
});

export default router;
