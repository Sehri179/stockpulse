import { Router } from "express";
import { db, alertsTable, stocksTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { z } from "zod";

const router = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return null; }
  return userId;
}

const createAlertSchema = z.object({
  symbol: z.string().min(1),
  targetPrice: z.number().positive(),
  condition: z.enum(["above", "below"]),
});

function alertToResponse(a: typeof alertsTable.$inferSelect, currentPrice: number) {
  return {
    id: a.id,
    userId: a.userId,
    symbol: a.symbol,
    name: a.name,
    targetPrice: a.targetPrice,
    condition: a.condition,
    currentPrice,
    isTriggered: a.isTriggered === 1,
    createdAt: a.createdAt.toISOString(),
  };
}

router.get("/", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const alerts = await db.select().from(alertsTable).where(eq(alertsTable.userId, userId));
  const enriched = await Promise.all(alerts.map(async (a) => {
    const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.symbol, a.symbol)).limit(1);
    return alertToResponse(a, stock?.currentPrice ?? 0);
  }));
  res.json(enriched);
});

router.post("/", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const parsed = createAlertSchema.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const { symbol, targetPrice, condition } = parsed.data;
  const sym = symbol.toUpperCase();

  const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.symbol, sym)).limit(1);
  if (!stock) { res.status(404).json({ error: "Stock not found" }); return; }

  // Check if already triggered
  const isTriggered = condition === "above"
    ? stock.currentPrice >= targetPrice
    : stock.currentPrice <= targetPrice;

  const [alert] = await db.insert(alertsTable).values({
    userId,
    symbol: sym,
    name: stock.name,
    targetPrice,
    condition,
    isTriggered: isTriggered ? 1 : 0,
  }).returning();

  res.status(201).json(alertToResponse(alert, stock.currentPrice));
});

router.delete("/:id", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const id = parseInt(req.params.id, 10);
  await db.delete(alertsTable).where(and(eq(alertsTable.id, id), eq(alertsTable.userId, userId)));
  res.json({ message: "Alert deleted" });
});

export default router;
