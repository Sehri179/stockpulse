import { Router } from "express";
import { db, holdingsTable, stocksTable, watchlistTable, usersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  return userId;
}

router.get("/", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  const holdings = await db.select().from(holdingsTable).where(eq(holdingsTable.userId, userId));

  const enrichedHoldings = await Promise.all(holdings.map(async (h) => {
    const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.id, h.stockId)).limit(1);
    const currentPrice = stock?.currentPrice ?? h.averagePrice;
    const totalValue = h.quantity * currentPrice;
    const totalCost = h.quantity * h.averagePrice;
    const gainLoss = totalValue - totalCost;
    const gainLossPercent = totalCost > 0 ? (gainLoss / totalCost) * 100 : 0;
    return {
      id: h.id,
      userId: h.userId,
      stockId: h.stockId,
      symbol: h.symbol,
      name: stock?.name ?? h.symbol,
      quantity: h.quantity,
      averagePrice: h.averagePrice,
      currentPrice,
      totalValue,
      gainLoss,
      gainLossPercent,
    };
  }));

  const totalInvested = enrichedHoldings.reduce((sum, h) => sum + h.quantity * h.averagePrice, 0);
  const totalValue = enrichedHoldings.reduce((sum, h) => sum + h.totalValue, 0) + (user?.balance ?? 0);
  const totalGainLoss = enrichedHoldings.reduce((sum, h) => sum + h.gainLoss, 0);
  const totalGainLossPercent = totalInvested > 0 ? (totalGainLoss / totalInvested) * 100 : 0;

  res.json({
    totalValue,
    totalInvested,
    totalGainLoss,
    totalGainLossPercent,
    cashBalance: user?.balance ?? 0,
    holdings: enrichedHoldings,
  });
});

router.get("/holdings", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const holdings = await db.select().from(holdingsTable).where(eq(holdingsTable.userId, userId));
  const enriched = await Promise.all(holdings.map(async (h) => {
    const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.id, h.stockId)).limit(1);
    const currentPrice = stock?.currentPrice ?? h.averagePrice;
    const totalValue = h.quantity * currentPrice;
    const totalCost = h.quantity * h.averagePrice;
    const gainLoss = totalValue - totalCost;
    const gainLossPercent = totalCost > 0 ? (gainLoss / totalCost) * 100 : 0;
    return { id: h.id, userId: h.userId, stockId: h.stockId, symbol: h.symbol, name: stock?.name ?? h.symbol, quantity: h.quantity, averagePrice: h.averagePrice, currentPrice, totalValue, gainLoss, gainLossPercent };
  }));
  res.json(enriched);
});

router.get("/watchlist", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const watchlist = await db.select().from(watchlistTable).where(eq(watchlistTable.userId, userId));
  const enriched = await Promise.all(watchlist.map(async (w) => {
    const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.symbol, w.symbol)).limit(1);
    return {
      id: w.id,
      userId: w.userId,
      symbol: w.symbol,
      name: stock?.name ?? w.symbol,
      currentPrice: stock?.currentPrice ?? 0,
      changePercent: stock?.changePercent ?? 0,
    };
  }));
  res.json(enriched);
});

router.post("/watchlist/:symbol", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const symbol = req.params.symbol.toUpperCase();
  const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.symbol, symbol)).limit(1);
  if (!stock) { res.status(404).json({ error: "Stock not found" }); return; }

  const [existing] = await db.select().from(watchlistTable)
    .where(and(eq(watchlistTable.userId, userId), eq(watchlistTable.symbol, symbol))).limit(1);
  if (existing) { res.status(201).json({ id: existing.id, userId, symbol, name: stock.name, currentPrice: stock.currentPrice, changePercent: stock.changePercent }); return; }

  const [entry] = await db.insert(watchlistTable).values({ userId, symbol }).returning();
  res.status(201).json({ id: entry.id, userId, symbol, name: stock.name, currentPrice: stock.currentPrice, changePercent: stock.changePercent });
});

router.delete("/watchlist/:symbol", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const symbol = req.params.symbol.toUpperCase();
  await db.delete(watchlistTable).where(and(eq(watchlistTable.userId, userId), eq(watchlistTable.symbol, symbol)));
  res.json({ message: "Removed from watchlist" });
});

export default router;
