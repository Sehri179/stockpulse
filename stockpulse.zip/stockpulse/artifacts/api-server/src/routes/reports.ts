import { Router } from "express";
import { db, holdingsTable, stocksTable, ordersTable, usersTable } from "@workspace/db";
import { eq, and, gte, lte } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any): number | null {
  const userId = req.session?.userId;
  if (!userId) { res.status(401).json({ error: "Unauthorized" }); return null; }
  return userId;
}

router.get("/portfolio-summary", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
  const holdings = await db.select().from(holdingsTable).where(eq(holdingsTable.userId, userId));

  const enriched = await Promise.all(holdings.map(async (h) => {
    const [stock] = await db.select().from(stocksTable).where(eq(stocksTable.id, h.stockId)).limit(1);
    const currentPrice = stock?.currentPrice ?? h.averagePrice;
    const totalValue = h.quantity * currentPrice;
    const totalCost = h.quantity * h.averagePrice;
    const gainLoss = totalValue - totalCost;
    const gainLossPercent = totalCost > 0 ? (gainLoss / totalCost) * 100 : 0;
    return { symbol: h.symbol, gainLoss, gainLossPercent, totalValue, totalCost };
  }));

  const totalInvested = enriched.reduce((s, h) => s + h.totalCost, 0);
  const totalHoldingsValue = enriched.reduce((s, h) => s + h.totalValue, 0);
  const cashBalance = user?.balance ?? 0;
  const totalValue = totalHoldingsValue + cashBalance;
  const totalReturn = totalHoldingsValue - totalInvested;
  const returnPercent = totalInvested > 0 ? (totalReturn / totalInvested) * 100 : 0;

  const best = enriched.length > 0 ? enriched.reduce((a, b) => a.gainLossPercent > b.gainLossPercent ? a : b) : null;
  const worst = enriched.length > 0 ? enriched.reduce((a, b) => a.gainLossPercent < b.gainLossPercent ? a : b) : null;

  res.json({
    totalValue,
    cashBalance,
    totalInvested,
    totalReturn,
    returnPercent,
    holdingsCount: holdings.length,
    bestPerformer: best ? { symbol: best.symbol, gainLossPercent: best.gainLossPercent } : null,
    worstPerformer: worst ? { symbol: worst.symbol, gainLossPercent: worst.gainLossPercent } : null,
  });
});

router.get("/profit-loss", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const { startDate, endDate } = req.query as { startDate?: string; endDate?: string };

  let sellOrders = await db.select().from(ordersTable).where(eq(ordersTable.userId, userId));
  sellOrders = sellOrders.filter(o => o.type === "sell");

  if (startDate) sellOrders = sellOrders.filter(o => o.createdAt >= new Date(startDate));
  if (endDate) sellOrders = sellOrders.filter(o => o.createdAt <= new Date(endDate));

  const allOrders = await db.select().from(ordersTable).where(eq(ordersTable.userId, userId));
  let totalProfit = 0, totalLoss = 0, profitableTrades = 0, losingTrades = 0;

  for (const sell of sellOrders) {
    // Find the matching buys for this symbol before this sell
    const buys = allOrders
      .filter(o => o.type === "buy" && o.symbol === sell.symbol && o.createdAt <= sell.createdAt);
    const avgBuyPrice = buys.length > 0 ? buys.reduce((s, o) => s + o.price, 0) / buys.length : sell.price;
    const profitLoss = (sell.price - avgBuyPrice) * sell.quantity - sell.fees;
    if (profitLoss >= 0) { totalProfit += profitLoss; profitableTrades++; }
    else { totalLoss += Math.abs(profitLoss); losingTrades++; }
  }

  const tradeCount = sellOrders.length;
  const winRate = tradeCount > 0 ? (profitableTrades / tradeCount) * 100 : 0;

  res.json({
    totalProfit,
    totalLoss,
    netProfitLoss: totalProfit - totalLoss,
    tradeCount,
    profitableTrades,
    losingTrades,
    winRate,
  });
});

router.get("/activity", async (req, res): Promise<void> => {
  const userId = requireAuth(req, res);
  if (!userId) return;

  const orders = await db.select().from(ordersTable).where(eq(ordersTable.userId, userId));
  const activity = orders.slice(-20).reverse().map(o => ({
    id: o.id,
    type: o.type,
    description: `${o.type === "buy" ? "Bought" : "Sold"} ${o.quantity} shares of ${o.symbol} at $${o.price.toFixed(2)}`,
    symbol: o.symbol,
    amount: o.totalAmount,
    createdAt: o.createdAt.toISOString(),
  }));

  res.json(activity);
});

export default router;
