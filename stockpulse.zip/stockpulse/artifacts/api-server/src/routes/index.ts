import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import stocksRouter from "./stocks";
import portfolioRouter from "./portfolio";
import ordersRouter from "./orders";
import alertsRouter from "./alerts";
import reportsRouter from "./reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/stocks", stocksRouter);
router.use("/portfolio", portfolioRouter);
router.use("/orders", ordersRouter);
router.use("/alerts", alertsRouter);
router.use("/reports", reportsRouter);

export default router;
