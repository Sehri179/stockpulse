import { pgTable, serial, integer, real, text, timestamp } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { stocksTable } from "./stocks";

export const holdingsTable = pgTable("holdings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  stockId: integer("stock_id").notNull().references(() => stocksTable.id),
  symbol: text("symbol").notNull(),
  quantity: real("quantity").notNull().default(0),
  averagePrice: real("average_price").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type Holding = typeof holdingsTable.$inferSelect;

export const watchlistTable = pgTable("watchlist", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  symbol: text("symbol").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type WatchlistEntry = typeof watchlistTable.$inferSelect;

export const ordersTable = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  stockId: integer("stock_id").notNull().references(() => stocksTable.id),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'buy' | 'sell'
  quantity: real("quantity").notNull(),
  price: real("price").notNull(),
  totalAmount: real("total_amount").notNull(),
  fees: real("fees").notNull().default(0),
  status: text("status").notNull().default("executed"), // 'pending' | 'executed' | 'cancelled'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Order = typeof ordersTable.$inferSelect;

export const alertsTable = pgTable("alerts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  targetPrice: real("target_price").notNull(),
  condition: text("condition").notNull(), // 'above' | 'below'
  isTriggered: integer("is_triggered").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Alert = typeof alertsTable.$inferSelect;
