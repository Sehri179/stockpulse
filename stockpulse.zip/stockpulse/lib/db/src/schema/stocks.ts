import { pgTable, serial, text, real, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const stocksTable = pgTable("stocks", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  name: text("name").notNull(),
  currentPrice: real("current_price").notNull(),
  openPrice: real("open_price").notNull(),
  highPrice: real("high_price").notNull(),
  lowPrice: real("low_price").notNull(),
  volume: integer("volume").notNull().default(0),
  change: real("change").notNull().default(0),
  changePercent: real("change_percent").notNull().default(0),
  sector: text("sector"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertStockSchema = createInsertSchema(stocksTable).omit({ id: true, updatedAt: true });
export type InsertStock = z.infer<typeof insertStockSchema>;
export type Stock = typeof stocksTable.$inferSelect;

export const priceHistoryTable = pgTable("price_history", {
  id: serial("id").primaryKey(),
  stockId: integer("stock_id").notNull().references(() => stocksTable.id),
  symbol: text("symbol").notNull(),
  date: text("date").notNull(),
  open: real("open").notNull(),
  high: real("high").notNull(),
  low: real("low").notNull(),
  close: real("close").notNull(),
  volume: integer("volume").notNull(),
});

export type PriceHistory = typeof priceHistoryTable.$inferSelect;
